import {db} from "../database_helper/mysql_connector";
import { OkPacket } from "mysql2";

export const removeExpiredItems = (now: number, callback: Function) => {
    const queryString = "DELETE FROM item WHERE EXPIRY < ?";

    db.query(
        queryString,
        [now],
        (err: Error, result: OkPacket)=> {
            if(err) {callback(err)};
            callback(null);
        }
    )
}

