import {db} from "../database_helper/mysql_connector";
import { OkPacket, RowDataPacket } from "mysql2";
import {Item} from "../models/item";

export const add = (item: Item, callback: Function) => {
    const queryString = "INSERT INTO item values (0, ?, ?, ?, NOW(), NOW(), 1)";

    db.query(
        queryString,
        [item.name, item.quantity, item.expiry],
        (err: Error, result: OkPacket)=> {
            if(err) {callback(err)};
            const insertId = (<OkPacket> result).insertId;
            callback(null, insertId);
        }
    )
}

export const quantity = (item: Item, callback: Function) => {
    const queryString = "select sum(quantity) as quantity, min(expiry) as expiry from item where name = ? and expiry > ?";

    db.query(
        queryString,
        [item.name, item.expiry],
        (err: Error, result: RowDataPacket)=> {
            if(err) {callback(err)};

            const row = (<RowDataPacket> result)[0];
            
            const resultItem: Item = {
                quantity: row.quantity,
                expiry: row.expiry
            }
            console.log(row.quantity);

            callback(null, resultItem);
        }
    );
}


export const aboutToExpireItem = (item: Item, callback: Function) => {
    const queryString = "select sum(quantity) as quantity from item where name = ? and expiry > min(expiry)";

    db.query(
        queryString,
        [item.name, item.expiry],
        (err: Error, result: RowDataPacket)=> {
            if(err) {callback(err)};

            const row = (<RowDataPacket> result)[0];
            
            const resultItem: Item = {
                quantity: row.quantity,
                expiry: row.expiry
            }
            console.log(row.quantity);

            callback(null, resultItem);
        }
    );
}

export const sell = (item: Item, callback: Function) => {
    itemQuantity(item, (err: Error, quantity: number)=> {
        if(item.quantity! <= quantity) {
            itemToBeExpiredSoon(item, (err: Error, toBeExpiredItem: Item) => {
                if(item.quantity! < toBeExpiredItem.quantity!) {
                    directSell(item, toBeExpiredItem.id!);
                } else if (item.quantity == toBeExpiredItem.quantity) {
                    sellRemainingLot(toBeExpiredItem.id!);
                } else if (item.quantity! > toBeExpiredItem.quantity!) {
                    const itemDifference = item.quantity! - toBeExpiredItem.quantity!;
                    sellRemainingLot(toBeExpiredItem.id!);
                    item.quantity = itemDifference;

                    sell(item, (err: Error, callback: Function) => null);
                }
            });
        }
    });
    
    callback(null, item);
}

const itemQuantity = (item: Item, callback: Function) => {
    var currentTime = Date.now();
    const queryString = "select sum(quantity) as quantity, min(expiry) as expiry from item where name = ? and expiry > ?";
    var quantity = 0;
    db.query(
        queryString,
        [item.name, currentTime],
        (err: Error, result: RowDataPacket)=> {
            if(err) { callback(err.message)};

            const row = (<RowDataPacket> result)[0];
            
            quantity = +row.quantity;
            
            callback(null, quantity);
        }
    );
}

const itemToBeExpiredSoon =  (item: Item, callback: Function) => {
    const currentTime = Date.now();
    const queryString = "select id, name, quantity from item where expiry = (select min(expiry) from item) and name = ? and expiry>?";
    var resultItem!: Item;
    db.query(
        queryString,
        [item.name, currentTime],
        (err: Error, result: RowDataPacket)=> {
            if(err) {callback(err.message)};

            const row = (<RowDataPacket> result)[0];
            
            resultItem = {
                id: row.id,
                quantity: row.quantity,
                name: row.name
            }
            console.log(row.id);
            callback(null, resultItem);
        }
    );
}

function directSell(item: Item, id: number) {
    const queryString = "UPDATE item SET quantity = quantity - ? WHERE id = ?";

    db.query(
        queryString,
        [item.quantity, id],
        (err: Error, result: OkPacket)=> {
            if(err) {console.log(err.message)};
            console.log("Item sold.");
        }
    )
}

function sellRemainingLot(id: number) {
    const queryString = "DELETE FROM item WHERE id = ?";

    db.query(
        queryString,
        [id],
        (err: Error, result: OkPacket)=> {
            if(err) {console.log(err.message)};
        }
    );
}
