import express, {Request, Response} from "express";
import * as itemQuery from "../queries/item";
import {Item} from "../models/item";


const itemRouter = express.Router();

itemRouter.post("/:item/add", async (req: Request, res: Response) => {
    var item: Item = {
        name: req.params.item,
        quantity: req.body.quantity,
        expiry: req.body.expiry
    }
    
    itemQuery.add(item, (err: Error, item: Item[]) => {
        if(err) {
            return res.status(500).json({"errorMessage": err.message});
        }

        res.status(200).json({});
    });

    console.log(req.params.item);
});

itemRouter.post("/:item/quantity", async (req: Request, res: Response) => {
    var currentTime = Date.now();
    var item: Item = {
        name: req.params.item,
        expiry: currentTime
    }
    
    itemQuery.quantity(item, (err: Error, item: Item) => {
        if(err) {
            return res.status(500).json({"errorMessage": err.message});
        }

        if(item.quantity != null && item.expiry != null) {
            item.quantity = +item.quantity;
            item.expiry = +item.expiry;
        }
        res.status(200).json({"quantity": item.quantity, "validTill": item.expiry});
    });

    console.log(req.params.item);
});

itemRouter.post("/:item/sell", async (req: Request, res: Response) => {
    var item: Item = {
        name: req.params.item,
        quantity: req.body.quantity
    }

    itemQuery.sell(item, (err: Error, item: Item) => {
        if(err) {
            return res.status(500).json({"errorMessage": err.message});
        }

        res.status(200).json({});
    });
});

export {itemRouter};