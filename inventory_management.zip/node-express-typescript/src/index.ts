import express, { Express, Request, Response } from 'express';
import helmet from 'helmet';
import * as dotenv from 'dotenv';
import {itemRouter} from "./routes/item_router";
import * as refreshDB from "./queries/refresh_list";

dotenv.config();

const PORT = process.env.PORT || 3000;
const app: Express = express();
const cron = require('node-cron');

cron.schedule('* * * * *', ()=>{
   var currentTime = Date.now();
   refreshDB.removeExpiredItems(currentTime, (err: Error, currentTime: number) => {
    if(err) {
      console.log("Error: " + err.message);
    }
    console.log("Database refreshed.");
});

});

app.use(helmet());
app.use(express.json());
app.use(express.urlencoded({
  extended: true
}));
app.use("/", itemRouter);

app.listen(PORT, ()=>console.log(`Running on ${PORT}`));